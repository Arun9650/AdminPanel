﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
//using DocumentFormat.OpenXml;
using System.IO;
using System.Xml.Linq;
using ClosedXML.Excel;

public partial class Admin_frmViewenquires : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            this.ViewEnquiryDetails();
            this.ViewEmployee();
            ViewState["Search"] = "All";
        }
    }

    protected void ViewEnquiryDetails()
    {
        try
        {
            using (SqlConnection con = new SqlConnection(Connection.ConnView))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("aspViewEnquirydetails", con);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                gvenquiry.DataSource = dt;
                gvenquiry.DataBind();              
                con.Close();
            }
        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
    }

    protected void gvenquiry_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        if (ViewState["Search"].ToString() == "All")
        {
            gvenquiry.PageIndex = e.NewPageIndex;
            this.ViewEnquiryDetails();
        }
        else if (ViewState["Search"].ToString() == "Search")
        {
            gvenquiry.PageIndex = e.NewPageIndex;
            this.ViewSearch();
        }
        else if (ViewState["Search"].ToString() == "Empwise")
        {
            gvenquiry.PageIndex = e.NewPageIndex;
            this.ViewEmpwiseEnquiry();
        }      
    }

    protected void btndatesearch_Click(object sender, EventArgs e)
    {
        try
        {
            lblerror.Text = "";
            ViewState["Search"] = "Search";
            this.ViewSearch();
            ddlemp.SelectedIndex = -1;
        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
    }

    protected void ViewSearch()
    {
        using (SqlConnection con = new SqlConnection(Connection.ConnView))
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("aspViewDatewiseEnquity", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@from", txtfrom.Text);
            cmd.Parameters.AddWithValue("@to", txtto.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            gvenquiry.DataSource = dt;
            gvenquiry.DataBind();          
            con.Close();
        }
    }

    protected void btnexportExcel_Click(object sender, EventArgs e)
    {
        try
        {
            this.ExportGridviewExcel();            
        }
        catch(Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
    }

    protected void ExportGridviewExcel()
    {
        DataTable dt = new DataTable("gridviewdata");
        foreach (TableCell cell in gvenquiry.HeaderRow.Cells)
        {
            dt.Columns.Add(HttpUtility.HtmlDecode(cell.Text));
        }
        foreach (GridViewRow row in gvenquiry.Rows)
        {
            dt.Rows.Add();
            for (int i = 0; i < row.Cells.Count; i++)
            {
                dt.Rows[dt.Rows.Count - 1][i] = HttpUtility.HtmlDecode(row.Cells[i].Text);
            }
        }
        using (XLWorkbook wb = new XLWorkbook())
        {
            wb.Worksheets.Add(dt, "Enquirysearch");
            Response.Clear();
            Response.Buffer = true;
            Response.Charset = "";
            Response.ContentType = "application/ms-excel";
            Response.AddHeader("content-disposition", "attachement;filename=EnquiryExport.xlsx");
            using (MemoryStream mstream = new MemoryStream())
            {
                wb.SaveAs(mstream);
                mstream.WriteTo(Response.OutputStream);
                Response.Flush();
                Response.End();
            }
        }
    }

    protected void ddlemp_SelectedIndexChanged(object sender, EventArgs e)
    {
        lblerror.Text = "";        
        ViewState["Search"] = "Empwise";
        this.ViewEmpwiseEnquiry();
       
    }

    protected void ViewEmpwiseEnquiry()
    {
        try
        {
            txtfrom.Text = txtto.Text = "";
            using (SqlConnection con = new SqlConnection(Connection.ConnView))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("aspViewEmpwiseEnquity", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@empid", Convert.ToInt32(ddlemp.SelectedValue));
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                gvenquiry.DataSource = dt;
                gvenquiry.DataBind();
               
                con.Close();
            }
        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
    }

    protected void ViewEmployee()
    {
        try
        {
            using (SqlConnection con = new SqlConnection(Connection.ConnView))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("aspSelectEmployees", con);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                ddlemp.DataSource = dt;
                ddlemp.DataBind();
                con.Close();
                ddlemp.Items.Insert(0, new ListItem("Select Employee","0"));
            }
        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
    }

}