﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Connection
/// </summary>
public class Connection
{
    public static string ConnView = "Data Source = 101.53.144.17,1232; Initial Catalog = EmpTracker; User Id = tracker; Password=123456; pooling=false;";
}